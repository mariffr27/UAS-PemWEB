<?php
$file = '../data.json';
if (!file_exists($file)) {
    echo json_encode(['error' => 'Data file not found']);
    exit;
}

$data = json_decode(file_get_contents($file), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Menambah pengguna baru
    $new_user = json_decode(file_get_contents('php://input'), true);
    if ($new_user) {
        $data[] = $new_user;
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
        echo json_encode(['message' => 'User added successfully']);
    } else {
        echo json_encode(['error' => 'Invalid user data']);
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/dashboard-admin.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-family: Arial, sans-serif;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        td {
            font-size: 14px;
            color: #333;
        }

        th {
            font-size: 16px;
            font-weight: bold;
        }

        .table-container {
            max-width: 90%;
            margin: 0 auto;
            overflow-x: auto;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .error-message {
            color: red;
            text-align: center;
        }

        .no-data {
            text-align: center;
            font-size: 18px;
            color: #888;
        }

        .form-container {
            margin: 20px auto;
            width: 50%;
        }

        input, button {
            padding: 8px;
            margin: 5px;
            width: 100%;
            box-sizing: border-box;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
        }

        button:hover {
            background-color: #45a049;
        }

        .form-container input[type="text"] {
            width: 48%;
            display: inline-block;
        }

        .form-container input[type="password"] {
            width: 48%;
            display: inline-block;
        }

        .form-container button {
            width: 100%;
        }

        img {
            max-width: 300px;
            height: auto;
        }
        .enroll-button {
            display: inline-block;
            margin: 10px 0;
            padding: 10px 15px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .video-list {
            list-style-type: none;
            padding: 0;
        }
        .video-list li {
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <header>
            <h1>Admin Dashboard</h1>
        </header>
        <nav>
            <ul>
                <li><a href="#" id="view-users">View Users</a></li>
                <li><a href="#" id="edit-users">Edit Users</a></li>
                <li><a href="#" id="view-courses">View Courses</a></li>
                <li><a href="#" id="edit-courses">Edit Courses</a></li>
                <li><a href="../Index.php">Website</a></li>
            </ul>
        </nav>
        <main>
            <div id="content"></div>
        </main>
    </div>
    <h2>Edit Courses</h2>
<button id="edit-courses">Edit Courses</button>
    <div id="content"></div>
    

<script>

    // VIEW USER
    document.getElementById('view-users').addEventListener('click', function(event) {
    event.preventDefault(); // Mencegah perilaku default tautan

        // Fetch users and display them
        fetch('../data.json')
            .then(response => response.json())
            .then(users => {
                let userContent = '<h2>User List</h2>';
                userContent += `<table border="1">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Passowrd</th>
                            <th>Role</th>
                        </tr>
                    </thead>
                    <tbody>`;

                // Loop through the users and display them in the table
                users.forEach(user => {
                    userContent += `
                        <tr>
                            <td>${user.name}</td>
                            <td>${user.email}</td>
                            <td>${user.password}</td>
                            <td>${user.role}</td>
                        </tr>
                    `;
                });

                userContent += `</tbody></table>`;

                // Display the content on the page
                document.getElementById('content').innerHTML = userContent;
            })
            .catch(error => {
                console.error('Error loading users:', error);
                document.getElementById('content').innerHTML = '<p class="error-message">Error loading users.</p>';
            });
    });

    // EDIT USER
    document.getElementById('edit-users').addEventListener('click', function(event) {
    event.preventDefault(); // Mencegah perilaku default tautan

    // Fetch users and display them
    fetch('users.php') // Ganti dengan path ke file PHP Anda
        .then(response => response.json())
        .then(users => {
            let userContent = '<h2>User List</h2>';
            userContent += `
                <h3>Add User</h3>
                <input type="text" id="new-name" placeholder="Name">
                <input type="email" id="new-email" placeholder="Email">
                <input type="password" id="new-password" placeholder="Password">
                <input type="text" id="new-role" placeholder="Role">
                <button id="add-user">Add User</button>
                <br><br>
                <table border="1">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>`;

            // Loop through the users and display them in the table
            users.forEach((user, index) => {
                userContent += `
                    <tr>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>${user.role}</td>
                        <td>
                            <button class="change-user" data-index="${index}">Change</button>
                            <button class="delete-user" data-index="${index}">Delete</button>
                        </td>
                    </tr>
                `;
            });

            userContent += `</tbody></table>`;

            // Display the content on the page
            document.getElementById('content').innerHTML = userContent;

            // Event listener for Add User button
            document.getElementById('add-user').addEventListener('click', function() {
                const newName = document.getElementById('new-name').value.trim();
                const newEmail = document.getElementById('new-email').value.trim();
                const newPassword = document.getElementById('new-password').value.trim();
                const newRole = document.getElementById('new-role').value.trim();

                if (newName && newEmail && newPassword && newRole) {
                    const newUser  = {
                        name: newName,
                        email: newEmail,
                        password: newPassword,
                        role: newRole
                    };

                    // Send new user to the server
                    fetch('users.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(newUser ),
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response .json();
                    })
                    .then(data => {
                        console.log(data.message); // Log success message
                        document.getElementById('edit-users').click(); // Refresh the user list
                    })
                    .catch(error => {
                        console.error('Error adding user:', error);
                    });
                } else {
                    alert('Please fill in all fields.');
                }
            });

            // Event listener for Change button
            document.querySelectorAll('.change-user').forEach(button => {
                button.addEventListener('click', function() {
                    const index = this.getAttribute('data-index');
                    const user = users[index];

                    // Prompt for new values
                    const newName = prompt('Edit Name:', user.name);
                    const newEmail = prompt('Edit Email:', user.email);
                    const newPassword = prompt('Edit Password:', user.password);
                    const newRole = prompt('Edit Role:', user.role);

                    // Update user if values are provided
                    if (newName && newEmail && newRole) {
                        users[index] = { ...user, name: newName, email: newEmail, password: newPassword, role: newRole };

                        // Send updated users to the server
                        fetch('users.php', {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(users),
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json();
                        })
                        .then(data => {
                            console.log(data.message); // Log success message
                            document.getElementById('edit-users').click(); // Refresh the user list
                        })
                        .catch(error => {
                            console.error('Error updating users:', error);
                        });
                    }
                });
            });

            // Event listener for Delete button
            document.querySelectorAll('.delete-user').forEach(button => {
                button.addEventListener('click', function() {
                    const index = this.getAttribute('data-index');
                    users.splice(index, 1); // Remove user from the array

                    // Send updated users to the server
                    fetch('users.php', {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(users),
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log(data.message); // Log success message
                        document.getElementById('edit-users').click(); // Refresh the user list
                    })
                    .catch(error => {
                        console.error('Error deleting user:', error);
                    });
                });
            });
        })
        .catch(error => {
            console.error('Error fetching users:', error);
        });
});


// VIEW COURSE
// Fetching course data from course.json and displaying it

document.getElementById('view-courses').addEventListener('click', function(event) {
    event.preventDefault(); 
// Fetching course data from course.json and displaying it
fetch('../course.json')
    .then(response => response.json())
    .then(data => {
        let courseContent = '<table><thead><tr><th>Title</th><th>Description</th><th>Materi</th><th>Materi Video</th><th>Image</th><th>Enroll Link</th><th>Video Tutorials</th></tr></thead><tbody>';
        
        for (const key in data) {
            const course = data[key]; // Accessing each course data
            const videoLinks = course.videoUrls.map(video => `${video.title} (${video.duration})`).join(', ');

            courseContent += `
                <tr>
                    <td>${course.title}</td>
                    <td>${course.description}</td>
                    <td>${course.materi}</td>
                    <td>${course.materiVideo}</td>
                    <td><img src="${course.image}" alt="${course.title}" style="max-width: 100px;"></td>
                    <td>${course.link}</td>
                    <td>${videoLinks}</td>
                </tr>
            `;
        }

        courseContent += '</tbody></table>';
        document.getElementById('content').innerHTML = courseContent; // Displaying the course content
    })
    .catch(error => {
        console.error('Error fetching course data:', error);
        document.getElementById('content').innerHTML = '<p class="error-message">Error loading course data.</p>';
    });

});

// EDIT Courses
document.getElementById('edit-courses').addEventListener('click', function(event) {
    event.preventDefault(); // Mencegah perilaku default tautan

    // Fetch courses and display them
    fetch('course.php') // Ganti dengan path ke file PHP Anda
        .then(response => response.json())
        .then(data => {
            let courseContent = '<h2>Edit Course List</h2>';
            courseContent += `<table border="1">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Materi</th>
                        <th>Materi Video</th>
                        <th>Image</th>
                        <th>Enroll Link</th>
                        <th>Video Tutorials</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>`;

            // Loop through the courses and display them in the table
            for (const key in data) {
                const course = data[key];

                // Create a string for video URLs
                const videoLinks = course.videoUrls.map(video => `${video.title} (${video.duration})`).join(', ');

                courseContent += `
                    <tr>
                        <td><input type="text" value="${course.title}" data-key="${key}" class="course-title"></td>
                        <td><input type="text" value="${course.description}" class="course-description"></td>
                        <td><input type="text" value="${course.materi}" class="course-materi"></td>
                        <td><input type="text" value="${course.materiVideo}" class="course-materiVideo"></td>
                        <td><input type="text" value="${course.image}" class="course-image"></td>
                        <td><input type="text" value="${course.link}" class="course-link"></td>
                        <td>
                            <div>
                                <input type="text" placeholder="Video Title" class="video-title">
                                <input type="text" placeholder="Video URL" class="video-url">
                                <input type="text" placeholder="Duration" class="video-duration">
                                <button class="add-video" data-key="${key}">Add Video</button>
                            </div>
                            <div class="video-list">${videoLinks}</div>
                        </td>
                        <td>
                            <button class="save-course" data-key="${key}">Save</button>
                        </td>
                    </tr>
                `;
            }

            courseContent += `</tbody></table>`;

            // Display the content on the page
            document.getElementById('content').innerHTML = courseContent;

            // Event listener for Save button
            document.querySelectorAll('.save-course').forEach(button => {
                button.addEventListener('click', function() {
                    const key = this.getAttribute('data-key');
                    const title = document.querySelector(`.course-title[data-key="${key}"]`).value;
                    const description = document.querySelector(`.course-description[data-key="${key}"]`).value;
                    const materi = document.querySelector(`.course-materi[data-key="${key}"]`).value;
                    const materiVideo = document.querySelector(`.course-materiVideo[data-key="${key}"]`).value;
                    const image = document.querySelector(`.course-image[data-key="${key}"]`).value;
                    const link = document.querySelector(`.course-link[data-key="${key}"]`).value;

                    // Get existing video URLs and add new ones
                    const videoUrls = data[key].videoUrls;

                    // Send updated course to the server
                    const updatedCourse = {
                        title,
                        description,
                        materi,
                        materiVideo,
                        image,
                        link,
                        videoUrls
                    };

                    // Send updated course to the server
                    fetch('course.php', {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ [key]: updatedCourse }),
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        alert(data.message); // Show success message
                    })
                    .catch(error => {
                        console.error('Error updating course:', error);
                        alert('Error updating course. Please try again.');
                    });
 });
            });

            // Event listener for Add Video button
            document.querySelectorAll('.add-video').forEach(button => {
                button.addEventListener('click', function() {
                    const key = this.getAttribute('data-key');
                    const title = document.querySelector(`.video-title`).value;
                    const url = document.querySelector(`.video-url`).value;
                    const duration = document.querySelector(`.video-duration`).value;

                    if (title && url && duration) {
                        const newVideo = { title, url, duration };
                        const videoList = document.querySelector(`.video-list`);

                        // Add new video to the existing list
                        videoUrls.push(newVideo);
                        videoList.innerHTML += `<div>${title} (${duration})</div>`;

                        // Clear input fields
                        document.querySelector(`.video-title`).value = '';
                        document.querySelector(`.video-url`).value = '';
                        document.querySelector(`.video-duration`).value = '';
                    } else {
                        alert('Please fill in all video details.');
                    }
                });
            });
        })
        .catch(error => {
            console.error('Error fetching courses:', error);
            document.getElementById('content').innerHTML = '<p class="error-message">Error loading course data.</p>';
        });
});
</script>



</body>
</html>
