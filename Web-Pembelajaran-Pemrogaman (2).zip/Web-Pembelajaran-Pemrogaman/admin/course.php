<?php
header('Content-Type: application/json');

$filename = '../course.json';

// Mendapatkan data kursus
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (file_exists($filename)) {
        $data = file_get_contents($filename);
        echo $data;
    } else {
        echo json_encode([]);
    }
}

// Memperbarui data kursus
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $input = file_get_contents('php://input');
    file_put_contents($filename, $input);
    echo json_encode(['message' => 'Data updated successfully']);
}
?>